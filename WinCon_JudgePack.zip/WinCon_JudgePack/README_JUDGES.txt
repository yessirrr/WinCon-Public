WinCon Judge Pack - Quick Start
================================
1. Extract entire folder to your Desktop
2. Double-click "Run WinCon (Demo).bat"
3. Use arrow keys to navigate, Enter to select
4. Press 'q' to quit

Note: Demo mode uses pre-cached data (no internet required).
For live data, configure .env and use "Run WinCon (Live).bat".

Questions? Contact the WinCon team.
